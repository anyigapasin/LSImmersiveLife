// CHANGED FRAGMENTS ONLY; see complete edited source for integration.

        private Dictionary<string, string> _incidentRecordingTypes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            var incidentRecordingTypes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var reusedEvents = new Dictionary<string, string>(StringComparer.Ordinal);

                    string reuse = (string)node.Attribute("reuseEvent");
                    if (!string.IsNullOrWhiteSpace(reuse))
                    {
                        if (entry.Clips.Count > 0) throw new InvalidDataException("A reused audio event cannot also declare clips: " + id);
                        reusedEvents.Add(id, reuse);
                    }

                }
                foreach (var reuse in reusedEvents)
                {
                    AudioEvent source;
                    if (reuse.Key == reuse.Value || reusedEvents.ContainsKey(reuse.Value)
                        || !events.TryGetValue(reuse.Value, out source) || source.Clips.Count == 0)
                        throw new InvalidDataException("Invalid recording reuse target: " + reuse.Value);
                    if (source.Speaker != events[reuse.Key].Speaker)
                        throw new InvalidDataException("Recording reuse must retain its actual speaker.");
                    events[reuse.Key].Clips.AddRange(source.Clips);
                }
                foreach (XElement alias in root.Elements("IncidentAliases").Elements("Alias"))
                {
                    string type = Required(alias, "type"), recording = Required(alias, "recordingType");
                    if (incidentRecordingTypes.ContainsKey(type)
                        || !events.Values.SelectMany(e => e.Clips).Any(c => c.Kind == recording))
                        throw new InvalidDataException("Invalid incident recording alias: " + type);
                    incidentRecordingTypes.Add(type, recording);

                    _events = events; _incidentRecordingTypes = incidentRecordingTypes;
                    _capacity = capacity; _language = language;

                string recordingType;
                string resolvedKind = incidentType ?? "";
                if (_incidentRecordingTypes.TryGetValue(resolvedKind, out recordingType))
                {
                    WarnOnce("recording-fallback:" + resolvedKind,
                        "No dedicated recording for " + resolvedKind + "; using catalog meaning " + recordingType + ".");
                    resolvedKind = recordingType;
                }

                    Event = entry, Scope = scopeId, Kind = resolvedKind, Agency = agency ?? "",
