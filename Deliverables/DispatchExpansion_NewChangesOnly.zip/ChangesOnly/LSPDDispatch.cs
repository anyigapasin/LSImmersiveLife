// CHANGED FRAGMENTS ONLY; see complete edited source for integration.

                if (_ambientWorld != null && !_ambientWorld.PrepareDispatchActivityResources(incident))
                {
                    reason = "Stage=ActivityResources; Result=DictionaryOrClipNotLoaded";
                    incident.ScenePreparationNextRetryAt = DateTime.UtcNow.AddMilliseconds(750);
                    return DateTime.UtcNow < incident.ScenePreparationDeadline
                        ? SceneOfferPreflightStatus.Pending : SceneOfferPreflightStatus.Failed;
                }

            Ped investigationVictim = PendingAuthoredMurderVictims(_incident)
                .OrderBy(p => p.Position.DistanceTo(player.Position)).FirstOrDefault();

            if (HasPendingVictimInvestigation)
                return "Victim examination recorded. Investigate the remaining authored victims with I before transport or completion.";

        private static IEnumerable<Ped> PendingAuthoredMurderVictims(LSPDDispatchEvent incident)
        {
            if (incident == null || !incident.VictimStartsDead) return Enumerable.Empty<Ped>();
            return new[] { incident.Victim }.Concat(incident.AdditionalParticipants.Take(incident.AdditionalDeadVictims))
                .Where(p => p != null && p.Exists() && !incident.InvestigatedVictimHandles.Contains(p.Handle));
        }


            Ped victim = PendingAuthoredMurderVictims(incident)
                .OrderBy(p => player == null ? 0f : p.Position.DistanceTo(player.Position)).FirstOrDefault();

            incident.InvestigatedVictimHandles.Add(victim.Handle);
            incident.VictimInvestigated = incident.InvestigatedVictimHandles.Count >= 1 + incident.AdditionalDeadVictims;

            incident.ResolvedSuspectHandles.Add(releasedHandle);

            bool allLivingTransferred = LiveSuspects(_incident).All(p =>
                _incident.ConvoyCustodySuspectHandles.Contains(p.Handle));
            _incident.OwnedByDispatch = !allLivingTransferred;
            _incident.HasConvoyCustodyHandoff = allLivingTransferred;
            if (allLivingTransferred) _incident.SurrenderRequested = false;

            if (allLivingTransferred)
            {
                CleanupBlip(_sceneBlip);
                CleanupSuspectBlips();
                _sceneBlip = null;
            }
            else SetStateForUnresolvedSuspects(LSPDDispatchState.Investigating);

                List<Ped> retainedArrested = _incident.ArrestedSuspects
                    .Where(p => p != null && p.Exists() && !p.IsDead).Concat(valid)
                    .GroupBy(p => p.Handle).Select(g => g.First()).ToList();

                _incident.ArrestedSuspects.AddRange(retainedArrested);
                // Other suspects retain their individual compliance and explicit
                // secure decisions while this physical custody subset recovers.

        internal bool HasAnyConvoyCustody
        {
            get { return _incident != null && _incident.ConvoyCustodySuspectHandles.Count > 0; }
        }


            return ResolveCompletedConvoyCustody("Prisoner delivered and booking completed.");

            return ResolveCompletedConvoyCustody("Transport officers have physically assumed the loaded custody group.");
        }

        private string ResolveCompletedConvoyCustody(string result)
        {
            if (_incident == null || !HasAnyConvoyCustody) return "No linked Dispatch custody remains.";
            LSPDDispatchEvent incident = _incident;
            var transferred = new HashSet<int>(incident.ConvoyCustodySuspectHandles);
            incident.ResolvedSuspectHandles.UnionWith(transferred);
            foreach (int handle in transferred)
            {
                _managedSuspectPresenceObservations.Remove(handle);
                _managedActorLostSuspectHandles.Remove(handle);
                _lastCompliantTaskAt.Remove(handle);
                ClearSecuredPoseTracking(handle);
                incident.SuspectResponses.Remove(handle);
                incident.ActivityTaskIssuedAt.Remove(handle);
            }
            incident.Suspects.RemoveAll(p => p == null || transferred.Contains(p.Handle));
            incident.ArrestedSuspects.RemoveAll(p => p == null || transferred.Contains(p.Handle));
            incident.CompliantSuspects.RemoveAll(p => p == null || transferred.Contains(p.Handle));
            if (incident.Suspect != null && transferred.Contains(incident.Suspect.Handle))
                incident.Suspect = incident.Suspects.FirstOrDefault(p => p != null && p.Exists() && !p.IsDead);
            incident.ConvoyCustodySuspectHandles.Clear();
            incident.HasConvoyCustodyHandoff = false;
            incident.OwnedByDispatch = true;
            if (LiveSuspects(incident).Any() || HasPendingVictimInvestigation)
            {
                SetStateForUnresolvedSuspects(LSPDDispatchState.Investigating);
                return result + " Other suspects or investigation remain; Dispatch stays active.";
            }
            Complete(result);
            return result + " Dispatch completed.";

                    bool authoredVehicleStopResponse = (IsVehicleEntryActivity(incident.VehicleActivity) || IsAuthoredDrivingActivity(incident))

            if (!MaintainAuthoredDispatchActivity(now, player)) return;

                    || IsVehicleEntryActivity(_incident.VehicleActivity) || IsAuthoredDrivingActivity(_incident))

                && ((IsVehicleEntryActivity(_incident.VehicleActivity) || IsAuthoredDrivingActivity(_incident))

                    if (string.IsNullOrEmpty(_incident.PreparedActivity))
                    {
                        TryStartInteriorStoreRobberyFlight(player);
                        MaintainStagedSceneBehavior(now);
                        MaintainVehicleSceneActivity(now, player);
                    }

            return string.Equals(sceneBehavior, "interior_activity", StringComparison.OrdinalIgnoreCase)
                || string.Equals(sceneBehavior, "interior_store_custody",

        private bool MaintainAuthoredDispatchActivity(DateTime now, Ped player)
        {
            if (_incident == null || string.IsNullOrEmpty(_incident.PreparedActivity)) return true;
            string reason = "AmbientWorld is unavailable";
            if (_ambientWorld == null) { Fail(reason); return false; }
            bool confirmed = _ambientWorld.MaintainPreparedDispatchActivity(_incident, now, out reason);
            if (!confirmed && reason.StartsWith("FAILED:", StringComparison.Ordinal))
            {
                Fail("The incident could not establish its authored activity after bounded recovery. " + reason);
                return false;
            }
            if (confirmed && !_incident.PreparedActivityAudioReported)
            {
                _incident.PreparedActivityAudioReported = true;
                ReportAudioStage("lsimmersivelife.police.scene.activity_confirmed", _incident, "activity-confirmed", true);
            }
            if (IsAuthoredDrivingActivity(_incident) && _incident.Suspect != null && _incident.Suspect.Exists())
            {
                // Location follows the actual lead car; passengers and the second
                // driver remain in the same occurrence and existing pursuit roster.
                _incident.Origin = _incident.Suspect.Position;
                if (!_incident.PlayerEncounterResponseStarted && player != null && player.Exists()
                    && LiveSuspects(_incident).Any(p => player.Position.DistanceTo(p.Position) < 45f))
                {
                    foreach (Ped actor in LiveSuspects(_incident))
                    {
                        _incident.SuspectResponses[actor.Handle] = "flee";
                        BeginDispatchVehicleFlightProtection(actor, _incident);
                        CapturePursuitVehicleHealthBaseline(_incident, actor);
                    }
                    _incident.PlayerEncounterResponseStarted = true;
                    SetStateForUnresolvedSuspects(LSPDDispatchState.SuspectFleeing);
                    ReportAudioStage("lsimmersivelife.police.pursuit.continuing", _incident, "vehicle-encounter", true);
                }
                // Each stopped driver/passenger can enter its own foot response.
                if (_incident.PlayerEncounterResponseStarted)
                    foreach (Ped actor in LiveSuspects(_incident).ToList())
                        MaintainStoppedPursuitVehicle(_incident, actor, player, now);
            }
            return true;
        }

        private static bool IsAuthoredDrivingActivity(LSPDDispatchEvent incident)
        {
            return incident != null && !string.IsNullOrEmpty(incident.PreparedActivity)
                && (incident.PreparedActivity.StartsWith("driving_", StringComparison.Ordinal)
                    || incident.PreparedActivity == "ramming");
        }



            if (!string.IsNullOrEmpty(_incident.PreparedActivity))
            {
                _incident.SceneBehaviorInitialized = true;
                _incident.PreArrivalSceneBehaviorInitialized = true;
                _incident.SceneBehaviorNextStepAt = DateTime.MaxValue;
                string activityReason;
                if (_ambientWorld != null)
                    _ambientWorld.MaintainPreparedDispatchActivity(_incident, DateTime.UtcNow, out activityReason);
                return;
            }

            if (incident == null || (!IsAuthoredDrivingActivity(incident) && !IsVehicleEntryActivity(incident.VehicleActivity))
                || (!IsAuthoredDrivingActivity(incident) && incident.VehicleActivityStage < 3)

                && (IsVehicleEntryActivity(incident.VehicleActivity) || IsAuthoredDrivingActivity(incident));

            int required = Math.Max(0, Math.Min(5, incident.SceneParticipantCount));

                || (incident.SceneResolution.IsInteriorScene && incident.SceneResolution.LiveInteriorId == 0)

                    || !LSPDDispatchEventDefinition.IsVictimStateReady(
                        index < incident.AdditionalDeadVictims, participant.IsDead, participant.Health)

                        || !LSPDDispatchEventDefinition.IsVictimStateReady(
                            incident.AdditionalParticipants.IndexOf(participant) < incident.AdditionalDeadVictims,
                            participant.IsDead, participant.Health))

            int required = Math.Max(0, Math.Min(5, incident.SceneParticipantCount));

                || (incident.SceneResolution.IsInteriorScene && incident.SceneResolution.LiveInteriorId == 0)

                    bool ready = LSPDDispatchEventDefinition.IsVictimStateReady(
                            index < incident.AdditionalDeadVictims, participant.IsDead, participant.Health)

                if (participant == null && index >= incident.AdditionalDeadVictims

                            index < incident.AdditionalDeadVictims,

                if (!string.IsNullOrEmpty(incident.PreparedActivity)) continue;

                    VehicleSeat assignedSeat = VehicleSeat.Driver;
                    if (assignedVehicle == null && incident.RequiresVehicle
                        && !IsVehicleEntryActivity(incident.VehicleActivity)
                        && incident.SceneResolution != null && !incident.SceneResolution.IsInteriorScene)
                    {
                        assignedVehicle = incident.SuspectVehicles[index % incident.SuspectVehicles.Count];
                        int capacity = Function.Call<int>(Hash.GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS, assignedVehicle);
                        int seat = Enumerable.Range(0, Math.Max(0, capacity)).Where(
                            value => Function.Call<bool>(Hash.IS_VEHICLE_SEAT_FREE, assignedVehicle, value, false))
                            .DefaultIfEmpty(-99).First();
                        if (seat == -99) { failureReason = "Insufficient real passenger seats for the authored group."; break; }
                        assignedSeat = (VehicleSeat)seat;
                    }

                        ? assignedVehicle.CreatePedOnSeat(assignedSeat, suspectModel)

            if (LiveSuspects(incident).Any(p => !incident.ConvoyCustodySuspectHandles.Contains(p.Handle))
                || HasPendingVictimInvestigation)
            {
                LogDebugTransition("POLICE_DISPATCH_COMPLETION_DEFERRED", incident.Id,
                    "Unresolved suspects or required investigation remain.");
                return;
            }

            if (deferSceneCleanup || incident.PreparedActivityStarted)

            {
                _ambientWorld.ReleasePreparedDispatchActivity(incident);

            }

                    .Where(ped => ped != null && ped.Exists()
                        && !incident.ConvoyCustodySuspectHandles.Contains(ped.Handle)))

                        PreserveUntilPlayerLeavesArea = deadAftermath || !string.IsNullOrEmpty(incident.PreparedActivity)

                        Expires = now.AddSeconds(DeferredCleanupMaximumSeconds),
                        PreserveUntilPlayerLeavesArea = !string.IsNullOrEmpty(incident.PreparedActivity)

                        Expires = now.AddSeconds(DeferredCleanupMaximumSeconds),
                        PreserveUntilPlayerLeavesArea = !string.IsNullOrEmpty(incident.PreparedActivity)

                        PreserveUntilPlayerLeavesArea = murderVictimAftermath || !string.IsNullOrEmpty(incident.PreparedActivity)

                        Expires = now.AddSeconds(DeferredCleanupMaximumSeconds),
                        PreserveUntilPlayerLeavesArea = !string.IsNullOrEmpty(incident.PreparedActivity)

            {
                _ambientWorld.ReleasePreparedDispatchActivity(incident);

            }

            if (IsAuthoredDrivingActivity(incident)) return true;
