// CHANGED FRAGMENTS ONLY; see complete edited source for integration.

        internal string PreparedActivity { get; private set; }

        internal int AdditionalDeadVictims { get; private set; }

            if (!new[] { "standard", "interior_activity", "paired_meeting", "paired_exchange", "interior_store_custody", "interior_robbery_custody", "interior_attack_attempt", "interior_clerk_assault", "interior_clerk_snatch", "murder_victim_alley", "murder_victim_exterior", "murder_victim_interior" }

                && !mappedRetailAttack
                && !string.Equals(sceneBehavior, "interior_activity", StringComparison.OrdinalIgnoreCase))

                node, "minimumSceneParticipants", 0, 0, 5);

                minimumSceneParticipants, 5);

                && !new[] { "shop_clerk", "shop_customer", "gun_store_clerk", "tattoo_store_clerk", "bank_clerk", "ambient_civilian" }.Contains(

            int additionalDeadVictims = IntegerInRange(node, "additionalDeadVictims", 0, 0, 4);
            if (additionalDeadVictims > minimumSceneParticipants || (additionalDeadVictims > 0 && !victimStartsDead))
                throw new InvalidDataException("Extra authored murder victims require reserved civilian slots and a murder scene.");

            string preparedActivity = Optional(node, "preparedActivity", string.Empty);
            string[] supportedPreparedActivities = { "threat", "assault", "driver_assault", "shooting", "stalking", "camera", "intoxicated", "lying", "theft", "exchange", "gathering", "murder", "driving_fast", "driving_slow", "ramming", "carjacking" };
            if (!string.IsNullOrEmpty(preparedActivity)
                && !supportedPreparedActivities.Contains(preparedActivity, StringComparer.OrdinalIgnoreCase))
                throw new InvalidDataException("Unsupported preparedActivity: " + preparedActivity);
            if ((preparedActivity == "exchange" || preparedActivity == "gathering") && minimumSuspects < 2)
                throw new InvalidDataException("Exchange/gathering needs at least two criminal participants.");
            if (preparedActivity.StartsWith("driving_", StringComparison.OrdinalIgnoreCase) || preparedActivity == "ramming")
                if (!Bool(node, "requiresVehicle", false) || !Bool(node, "mobile", false))
                    throw new InvalidDataException("A driving activity requires mobile vehicles.");

            bool interiorActivity = string.Equals(sceneBehavior, "interior_activity", StringComparison.OrdinalIgnoreCase);
            if (interiorActivity && (string.IsNullOrEmpty(preparedActivity)
                || string.IsNullOrEmpty(requiredPhysicalType) || Bool(node, "requiresVehicle", false)))
                throw new InvalidDataException("An authored interior activity needs a physical site, activity, and foot actors.");
            bool inferredMappedInterior = interiorActivity || mappedInteriorRobberyCustody

                    || maximumSuspects > 5

                    "A mapped interior robbery requires one to five armed bank/store suspects, one matching clerk or civilian victim, compliance and resistance branches, no vehicle or exterior staging, and no paired animation.");

                    || maximumSuspects > 5

                    || maximumSuspects > 5

                    || maximumSuspects > 5

                && string.IsNullOrEmpty(preparedActivity)

            if (!interiorActivity && !interiorStoreCustody && !mappedInteriorRobberyCustody

                PreparedActivity = preparedActivity,

                AdditionalDeadVictims = additionalDeadVictims,

        internal string PreparedActivity { get; set; }
        internal bool PreparedActivityStarted { get; set; }
        internal bool PreparedActivityConfirmed { get; set; }
        internal bool PreparedActivityAudioReported { get; set; }
        internal HashSet<int> ResolvedSuspectHandles { get; private set; } = new HashSet<int>();
        internal Dictionary<int, DateTime> ActivityLastEvidenceAt { get; private set; } = new Dictionary<int, DateTime>();
        internal DateTime PreparedActivityStartedAt { get; set; }
        internal DateTime PreparedActivityNextSampleAt { get; set; }
        internal int PreparedActivitySamples { get; set; }
        internal bool RammingImpactConfirmed { get; set; }
        internal Dictionary<int, int> ActivityStages { get; private set; } = new Dictionary<int, int>();
        internal int PreparedActivityRecoveryCount { get; set; }
        internal Dictionary<int, Vector3> ActivitySamplePositions { get; private set; } = new Dictionary<int, Vector3>();
        internal Dictionary<int, DateTime> ActivityTaskIssuedAt { get; private set; } = new Dictionary<int, DateTime>();
        internal Dictionary<int, string> ActivityRoles { get; private set; } = new Dictionary<int, string>();
        internal HashSet<int> ActivityEvidenceHandles { get; private set; } = new HashSet<int>();
        internal List<Prop> ActivityProps { get; private set; } = new List<Prop>();

        internal int AdditionalDeadVictims { get; set; }
        internal HashSet<int> InvestigatedVictimHandles { get; private set; } = new HashSet<int>();

                PreparedActivity = definition.PreparedActivity,

                AdditionalDeadVictims = definition.AdditionalDeadVictims,
