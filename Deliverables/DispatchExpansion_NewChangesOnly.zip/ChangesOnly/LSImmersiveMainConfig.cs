// CHANGED FRAGMENTS ONLY; see complete edited source for integration.

        internal static LSPoliceDispatchSettings Default() { return new LSPoliceDispatchSettings { Enabled = true, MinimumQuietPatrolSeconds = 180, MaximumQuietPatrolSeconds = 600, RepeatProtectionMinutes = 20, MaximumActiveIncidents = 1, MaximumSuspects = 5, AudioMinimumGapSeconds = 5, ContextClearQuietSeconds = 30, PlayerRadiusFallbackMinimumDistanceMeters = 80, PlayerRadiusFallbackMaximumDistanceMeters = 150 }; }
