// CHANGED FRAGMENTS ONLY; see complete edited source for integration.

                && Dispatch.HasAnyConvoyCustody)

                if (!Dispatch.HasIncident) Backup.BeginStandDown(

            if (Dispatch.HasAnyConvoyCustody)

            if (!Dispatch.HasIncident) Backup.BeginStandDown("Custody operation completed.");

            if (Convoy.Completed && Dispatch.HasAnyConvoyCustody)

            if (Convoy.Completed && Dispatch.HasAnyConvoyCustody)
