// CHANGED FRAGMENTS ONLY; see complete edited source for integration.

                if (targets.Count >= 5)
